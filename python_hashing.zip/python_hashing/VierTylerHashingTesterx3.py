from VierTylerHashingx3 import GetArray, PrintArray, HashAnalysis, HashSearch, HashSummary

print("Tyler Vier\n")
print("Hash Tables\n\n")

print("###################################################################\n")
print("Hash Algorithm #1 - Standard Linear\n")
print("###################################################################\n")
print("#################--> Building The Table <--#########################\n")



GetArray("Dean", 31415)
PrintArray()
GetArray("Megan", 21423)
PrintArray()
GetArray("Johny", 24608)
PrintArray()
GetArray("Davon", 12995)
PrintArray()
GetArray("Cody", 10727)
PrintArray()
GetArray("Messy", 61516)
PrintArray()
GetArray("Gracie", 66467)
PrintArray()
GetArray("Ellie", 44871)
PrintArray()
GetArray("Coley", 10851)
PrintArray()
GetArray("Jessie", 22015)
PrintArray()
GetArray("Noah", 65417)
PrintArray()
GetArray("Kayla", 94537)
PrintArray()

HashAnalysis()

print("#################--> Searching The Table <--#########################")

HashSearch(60241)
HashSearch(31415)
HashSearch(68215)
HashSearch(61516)
HashSummary()
