from VierTylerJumpHashingAnalysis import jumpAnalysis, PrintJump, roundArray

print("Tyler Vier")
print("Hashing Analysis\n")
print("*******************************************************************")
print("Algorithm 2 - Jump Hashing")
print("*******************************************************************\n")


jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
jumpAnalysis()
roundArray()
PrintJump()
