import random

global collisions, records, probetotal, probeaverage, searchtotal
probetotal = 0
collisions = 0
records = 0
probeaverage = 0
searchtotal = 0
idarray = [0]*100
valuearray = [0]*100
k = 3

def GetArrayJump(idnum):
    global collisions
    collisions = 0
    idnumshort = idnum % 100
    while idarray[idnumshort] != 0:
        collisions += 1
        idnumshort = (idnumshort + k) % 100
    idarray[idnumshort] = idnum
    return(collisions)

def HashSearchJump(idnum):
    probes = 0
    idnumshort = idnum % 100
    if idarray[idnumshort] == 0:
        probes += 1
    elif idarray[idnumshort] == idnum:
        probes += 1
    else:
        probes += 1
        while idarray[idnumshort] != idnum and idarray[idnumshort] != 0:
            idnumshort = (idnumshort + k) % 100
            probes += 1
    return(probes, -1)
        
collisionArray = [0] * 100
FArray = [0] * 100
NFArray = [0] * 100
def jumpAnalysis():
    global collisions
    i = 0
    for i in range(len(valuearray)):
        idarray[i] = 0
        valuearray[i] = 0
    i = 0
    j = 0
    for i in range(99):
        total = 0
        newtotal = 0
        fprobes = 0
        nfprobes = 0
        value = random.randint(10000, 99999)
        valuearray[i] = value
        GetArrayJump(value)
        collisionArray[i] += collisions
        collisions = 0
        fprobes = 0
        nfprobes = 0
        for j in range (10):
            result1 = FTarget(valuearray)
            input1 = result1[1]
            var1 = HashSearchJump(input1)
            fprobes = var1[0]
            result2 = NFTarget(valuearray)
            input2 = result2[1]
            var2 = HashSearchJump(input2)
            nfprobes = var2[0]
            FArray[i] += fprobes/10
            NFArray[i] += nfprobes/10

def FTarget(valuearray):
    result = random.choice(valuearray)
    while result == 0:
        result = random.choice(valuearray)
    return(valuearray, result)

def NFTarget(valuearray):
    result = random.randint(10000, 99999)
    for i in range (len(valuearray)):
        if result == valuearray[i]:
            return(NFTarget(valuearray))
    return(valuearray, result)

def roundArray():
    i = 0
    for i in range (100):
        cols = collisionArray[i]
        cols = round(cols/10, 1)
        collisionArray[i] = cols
        farray = FArray[i]
        farray = round(farray/10, 1)
        FArray[i] = farray
        nfarray = NFArray[i]
        nfarray = round(nfarray/10, 1)
        NFArray[i] = nfarray

def PrintJump():
    i = 0
    print(" RECORDS   COLLISONS   FOUND PROBES   NOT-FOUND PROBES")
    for i in range (100):
        print(str(i+1).rjust(6), str(collisionArray[i]).rjust(11), str(FArray[i]).rjust(13), str(NFArray[i]).rjust(12))
