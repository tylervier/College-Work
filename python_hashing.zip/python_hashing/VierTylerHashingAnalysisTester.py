from VierTylerHashingAnalysis import linearAnalysis, PrintLinear, roundArray

print("Tyler Vier")
print("Hashing Analysis\n")
print("*******************************************************************")
print("Algorithm 1 - Linear Hashing")
print("*******************************************************************\n")


linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
linearAnalysis()
roundArray()
PrintLinear()
