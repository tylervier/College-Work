global collision, records, probetotal, probeaverage, searchtotal
probetotal = 0
collision = 0
records = 1
probeaverage = 0
searchtotal = 0
namearray = [0]*100
idarray = [0]*100

def GetArray(name, idnum):
    global collision, records, probetotal, probeaverage
    print("\nEnter Record #" + str(records) + ":")
    idnumshort = idnum % 100
    print("   Name:   ", name)
    print("   ID:     ", idnum)
    while idarray[idnumshort] != 0:
        collision += 1
        print("   Calculating hashing index:   ", idnumshort, " (Collision #" + str(collision) + " - " + str(namearray[idnumshort]) + ", " + str(idarray[idnumshort]) + ")")
        idnumshort = (idnumshort + 3) % 100
    namearray[idnumshort] = name
    idarray[idnumshort] = idnum
    print("   Calculating hashing index:   ", idnumshort, "(Empty)")
    print("   Storing in location   ", idnumshort)
    records += 1
    print("")

def PrintArray():
    print("   \n\nCurrent Table:\n")
    print("      INDEX   NAME     ID")
    for i in range(100):
        if idarray[i] != 0:
            print(str(i).rjust(8), str(namearray[i]).rjust(9), str(idarray[i]).rjust(8))

def HashAnalysis():
    global collision, records, probetotal, probeaverage
    print("Table complete. ", records, "records in 100 spaces, with", collision, "collisions\n")

def HashSearch(idnum):
    global collision, records, probetotal, probeaverage, searchtotal
    searchtotal += 1
    probe = 0
    print("\nSearch # " + str(searchtotal) + ":")
    print("   Enter ID:   ", idnum)
    idnumshort = idnum % 100
    if idarray[idnumshort] == 0:
        print("   Calculated index:   ", idnumshort, "   (Empty)")
        print("   Not in table")
        probe += 1
    elif idarray[idnumshort] == idnum:
        print("   Calculated index:   ", idnumshort, "(", str(namearray[idnumshort]), ",", str(idarray[idnumshort]), ")")
        print("   Found at index:     ", idnumshort)
        probe += 1
    else:
        while idarray[idnumshort] != 0 and idarray[idnumshort] != idnum:
            print("   Calculated index:   ", idnumshort, "(", str(namearray[idnumshort]), ",", str(idarray[idnumshort]), ")")
            probe += 1
            idnumshort = (idnumshort + 3) % 100
        if idarray[idnumshort] == 0:
            print("   Calculated index:   ", idnumshort, "   (Empty)")
            print("   Not in table")
            probe += 1
        else:
            print("   Found at index:     ", idnumshort)
            probe += 1
    if probe < 2:
        print("   Required", probe, "probe")
    else:
        print("   Required", probe, "probes")
    probetotal += probe

def HashSummary():
    global collision, records, probetotal, probeaverage, searchtotal
    probeaverage = probetotal / searchtotal
    print("\nSummary:   Performed ", searchtotal, " searches, requiring ", probetotal, " probes,\n" + "           for an average of ", probeaverage, " probes per search")
    
