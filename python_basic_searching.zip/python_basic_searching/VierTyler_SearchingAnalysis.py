###########################################################################
#  linearSearch                                                           #
#                                                                         #
#  Looks for a specific target within an unsorted list of integers.       #
#  Returns the index of the first occurrence of the target.  If the       #
#  target is not in the list, -1 is returned.                             #
###########################################################################

import random

def linearSearch(target, array):
    for i in range(len(array)):
        if array[i]==target:
            return(i,i+1)
    return(-1,i+1)       

###########################################################################
#  binSearch                                                              #
#                                                                         #
#  Looks for a specific target within a sorted list of integers.          #
#  Returns the middle of the array and whether or not the target is       #
#  Above or below the middle value. This repeats until the target is      #
#  Found                                                                  #
###########################################################################

def binSearch (array, target, left, right, probe):
    if left<=right:
        mid = (left + right)//2
        if array[mid] == target:
            return (mid, probe)
        elif array[mid] < target:
            return binSearch(array, target, mid+1, right, probe+1)
        else:
            return binSearch(array, target, left, mid-1, probe+1)
    else:
        return (-1, probe)

###########################################################################
#  linearAnalysis                                                         #
#                                                                         #
#  Looks for a specific target within a sorted list of integers.          #
#  Returns the average amount of probes for each array size.              #
#                                                                         #
###########################################################################

def linearAnalysis (arraylength):
    sum = 0
    for count in range(arraylength):
        array = random.sample(range(1, arraylength+1), arraylength)
        target = random.choice(array)
        result = linearSearch(target, array)
        probes = result[1]
        sum = sum + probes
    print('%11d %19.2f'%(arraylength, sum/arraylength))

###########################################################################
#  binAnalysis                                                            #
#                                                                         #
#  Looks for a specific target within a sorted list of integers.          #
#  Returns the average amount of probes for each array size.              #
#                                                                         #
###########################################################################

def binAnalysis (arraylength):
    sum = 0
    for count in range(arraylength):
        array = random.sample(range(1, arraylength+1), arraylength)
        array.sort()
        target = random.choice(array)
        result = binSearch(array, target, 0, arraylength-1, 0)
        probes = result[1]
        sum = sum + probes
    print('%11d %19.2f'%(arraylength, sum/arraylength))
