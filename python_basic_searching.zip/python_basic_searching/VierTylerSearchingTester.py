from VierTylerSearching import linearSearch, binSearch

print ("Tyler Vier")
print ("Searching Algorithms\n")

print ("******************************************************************\n")

print ("Part 1 - Linear Search\n")

array = [31,41,59,24,53,58,97,93,23,84,62,64,33,83,27,95]
length = len(array)

target = 62
linearSearch(array, target)

target = 59
linearSearch(array, target)

target = 37
linearSearch(array, target)

print ("******************************************************************\n")


print ("Part 2 - Binary Search\n")

array = [23,24,27,31,33,41,53,58,59,62,64,83,84,93,95,97]

target = 62
print("\ntarget = ", target)
print("PROBE   LEFT   RIGHT   VALUE   RESULT")
binSearch(array, target, 0, length-1, 0)
target = 59
print("\ntarget = ", target)
print("PROBE   LEFT   RIGHT   VALUE   RESULT")
binSearch(array, target, 0, length-1, 0)
target = 37
print("\ntarget = ", target)
print("PROBE   LEFT   RIGHT   VALUE   RESULT")
binSearch(array, target, 0, length-1, 0)
