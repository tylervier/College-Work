from VierTyler_SearchingAnalysis import linearSearch, binSearch, linearAnalysis, binAnalysis
import random


print ("Tyler Vier")
print ("Searching Analysis\n")

print ("******************************************************************\n")

print ("Part 1 - Linear Search Analysis\n")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#array of 10
linearAnalysis (10)
#array of 50
linearAnalysis (50)
#array of 100
linearAnalysis (100)
#array of 500
linearAnalysis (500)
#array of 1000
linearAnalysis (1000)

print ("******************************************************************\n")


print ("Part 2 - Binary Search Analysis\n")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#array of 10
binAnalysis (10)
#array of 50
binAnalysis (50)
#array of 100
binAnalysis (100)
#array of 500
binAnalysis (500)
#array of 1000
binAnalysis (1000)
