###########################################################################
#  linearSearch                                                           #
#                                                                         #
#  Looks for a specific target within an unsorted list of integers.       #
#  Returns the index of the first occurrence of the target.  If the       #
#  target is not in the list, -1 is returned.                             #
###########################################################################

def linearSearch(array, target):
    print("target: ", target)
    print("PROBE   INDEX   VALUE   RESULT")
    length = len(array)
    p = 1
    j = 0
    found = False
    for i in range(length):
          if array[i]==target:
              print("  ", p, "  ", array[i], "   target")
              print("Target found in ", p, " probes")
              found = True
              break
          elif array[i] != target:
              print("  ", p, "  ", array[i], "   not target")
          p=p+1
          j=j+1
          
    if found == False:
          print("Target not found in ", p, "probes")

###########################################################################
#  binSearch                                                              #
#                                                                         #
#  Looks for a specific target within a sorted list of integers.          #
#  Returns the middle of the array and whether or not the target is       #
#  Above or below the middle value. This repeats until the target is      #
#  Found                                                                  #
###########################################################################

def binSearch (array, target, left, right, probe):
    if left<=right:
        mid = (left + right)//2
        if array[mid] == target:
            print(str(probe+1).rjust(3), str(left).rjust(6), str(right).rjust(6), str(mid).rjust(5), str(array[mid]).rjust(5), str ("target").rjust(9))
            print("Target found in ", probe+1, " probes")
            return mid
        elif array[mid] < target:
            print(str(probe+1).rjust(3), str(left).rjust(6), str(right).rjust(6), str(mid).rjust(5), str(array[mid]).rjust(5), str ("not target; upper half").rjust(25))
            return binSearch(array, target, mid+1, right, probe+1)
        else:
            print(str(probe+1).rjust(3), str(left).rjust(6), str(right).rjust(6), str(mid).rjust(5), str(array[mid]).rjust(5), str ("not target; lower half").rjust(25))
            return binSearch(array, target, left, mid-1, probe+1)
    else:
        print("Target not found, required ", probe, " probes")
