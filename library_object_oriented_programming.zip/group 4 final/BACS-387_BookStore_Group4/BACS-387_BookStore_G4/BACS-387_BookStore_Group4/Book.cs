﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class Book
    {
        public string title { get; set; }

        public string author { get; set; }

        public string isbn { get; set; }

        public bool check { get; set; }

        public Book CheckDigit10(Book book)
        {
            int sum = 0;
            for (int i = 0; i < 9; i++)
                sum += (10 - i) * Int32.Parse(isbn[i].ToString());
            int rem = sum % 11;
            int digit = 11 - rem;
            if (digit == 10)
                book.check = false;
            else
                book.check = true;
            return (book);
        }
    }
}
