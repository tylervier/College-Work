﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BACS_387_BookStore_Group4
{
    class Functions
    {
        public void writeFile(Book data)
        {
            StreamWriter sw = new StreamWriter("..//..//Bookstore.txt", true);
            sw.WriteLine(data.title + "/" + data.author + "/" + data.isbn);
            sw.Close();
        }

        public string[,] allBooks()
        {
            string[,] booksArray = new String[101, 3];
            int i = 0;
            foreach (string line in File.ReadAllLines("..//..//Bookstore.txt"))
            {
                string[] parts = line.Split('/');
                booksArray[i, 0] = parts[0];
                booksArray[i, 1] = parts[1];
                booksArray[i, 2] = parts[2];
                i++;
            }
            return booksArray;
        }
        public string[] readFile(Book data)
        {
            string[] readFile = new string[50];
            int i = 0;
            foreach (string line in File.ReadAllLines("..//..//Bookstore.txt"))
            {
                readFile[i] = line;
                i++;
            }
            return readFile;
        }
        public void reWriteBooks(string[,] allBooks)
        {
            StreamWriter sw = new StreamWriter("..//..//Bookstore.txt", false);
            for (int i = 0; i < 100; i++)
            {
                string writeString = (allBooks[i, 0] + "/" + allBooks[i, 1] + "/" + allBooks[i, 2]);
                if (writeString != "//")
                {
                    sw.WriteLine(writeString);
                }
            }
            sw.Close();
        }
    }

}

