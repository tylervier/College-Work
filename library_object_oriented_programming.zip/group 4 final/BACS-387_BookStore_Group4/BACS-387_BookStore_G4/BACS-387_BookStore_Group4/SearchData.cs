﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class SearchData
    {
        public string searchPhrase { get; set; }

        public List<Book> bookSearchList { get; set; }

    }
}
