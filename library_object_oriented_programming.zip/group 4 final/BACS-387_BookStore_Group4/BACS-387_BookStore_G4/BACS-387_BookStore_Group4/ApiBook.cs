﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class ApiBook
    {
        public string title { get; set; }
        public string isbn10 { get; set; }
        public List<Author> author_data { get; set; }

    }
}
