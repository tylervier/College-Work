﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json.Linq;


namespace BACS_387_BookStore_Group4
{
    class WebAccessor
    {
        private string key = "BL80PN3X";

        public Book obtianBookFromAPI(Book book)
        {
            string url = string.Format(@"http://isbndb.com/api/v2/json/{0}/book/{1}", key, book.isbn);

            WebClient webClient = new WebClient();

            string bookDataFromAPI = webClient.DownloadString(url);

            book = convertToBook(bookDataFromAPI);

            Functions writeFunction = new Functions();
            writeFunction.writeFile(book);

            return book;
        }

        private Book convertToBook(string data)
        {
            Book book = new Book();

            JObject rawData = JObject.Parse(data);
            List<JToken> token = rawData["data"].Children().ToList();
            JToken firstToken = token.First();

            ApiBook apiBook = firstToken.ToObject<ApiBook>();

            book.title = apiBook.title;
            book.isbn = apiBook.isbn10;
            book.author = apiBook.author_data.First().name;

            return book;
        }

    }
}
