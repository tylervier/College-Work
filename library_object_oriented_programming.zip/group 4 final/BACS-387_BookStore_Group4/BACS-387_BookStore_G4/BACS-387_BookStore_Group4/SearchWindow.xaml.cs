﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BACS_387_BookStore_Group4
{
    /// <summary>
    /// Interaction logic for SearchWindow.xaml
    /// </summary>
    public partial class SearchWindow : Window
    {
        private List<Book> savedBooks;
        public SearchWindow()
        {
            InitializeComponent();

        }

        private void buildFakeSavedBookList()
        {
            savedBooks = new List<Book>();
        
            for (int i = 1; i < 6; i++)
            {
                Book fakeBook = new Book();
                fakeBook.title = ("Title " + Convert.ToString(i));
                fakeBook.author = ("Author "  + Convert.ToString(i));
                fakeBook.isbn = (Convert.ToString(i) + "234567890");
                savedBooks.Add(fakeBook);
            }

            Book similarAuthorFakeBook = new Book();
            similarAuthorFakeBook.title = ("Title 6");
            similarAuthorFakeBook.author = ("Author 1");
            similarAuthorFakeBook.isbn = ("9876543210");
            savedBooks.Add(similarAuthorFakeBook);

        }

        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            inputSearchData.Clear();
            listBoxResults.Items.Clear();           
        }

        private void searchButton_Click(object sender, RoutedEventArgs e)
        {
            listBoxResults.Items.Clear();
            Book search = new Book();
            BookFunctions function = new BookFunctions();
            search.isbn = inputSearchData.Text;
            search = function.searchBook(search);
            if (search.check == true)
            {
                listBoxResults.Items.Add(search.title + "/" + search.author + "/" + search.isbn);
            }
            else
            {
                listBoxResults.Items.Add("No Book Found.");
            }
        }

        private void cancelSearch_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void loadAll_Click(object sender, RoutedEventArgs e)
        {
            Functions load = new Functions();
            string[,] display = load.allBooks();
            string output = "";

            listBoxResults.Items.Clear();
            for (int i = 0; i < 100; i++)
            {
                output = (display[i, 0] + "/" + display[i, 1] + "/" + display[i, 2]);
                if (output != "//")
                {
                    listBoxResults.Items.Add(output);
                    output = "";
                }
            }
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            Book remove = new Book();
            BookFunctions removeBook = new BookFunctions();
            remove.isbn = inputSearchData.Text;
            removeBook.removeBook(remove);
        }
    }
}
