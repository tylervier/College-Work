﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BACS_387_BookStore_Group4
{
    /// <summary>
    /// Interaction logic for ISBNAddBookWindow.xaml
    /// </summary>
    public partial class ISBNAddBookWindow : Window
    {
        private List<Book> toSaveList = new List<Book>();

        public ISBNAddBookWindow()
        {
            InitializeComponent();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void isbnSearch_Click(object sender, RoutedEventArgs e)
        {
            WebAccessor webAccessor = new WebAccessor();
            Book book = new Book();
            
            book.isbn = isbnToSearch.Text;

            toSaveList.Add(webAccessor.obtianBookFromAPI(book));

            booksToAddList.ItemsSource = null;
            booksToAddList.ItemsSource = toSaveList;

        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            isbnToSearch.Clear();
            booksToAddList.ItemsSource = null;
        }
    }
}
