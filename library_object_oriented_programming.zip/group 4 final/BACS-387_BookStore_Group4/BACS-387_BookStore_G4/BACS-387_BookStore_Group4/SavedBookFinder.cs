﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class SavedBookFinder
    {

        private List<Book> matchingItems;
        public List<Book> FindMatchingBooks (SearchData searchData)
        {
            matchingItems = new List<Book>();

            foreach (Book searchedBook in searchData.bookSearchList)
            {
                if(searchData.searchPhrase.ToUpper() == searchedBook.title.ToUpper() || searchData.searchPhrase.ToUpper() == searchedBook.author.ToUpper() || searchData.searchPhrase.ToUpper() == searchedBook.isbn)
                {
                    matchingItems.Add(searchedBook);
                }
            }

            if (matchingItems.Count == 0)
            {
                Book noMatch = new Book();
                noMatch.title = "No Matching Items Found";
                matchingItems.Add(noMatch);
            }

            return matchingItems;
          

        }
    }
}
