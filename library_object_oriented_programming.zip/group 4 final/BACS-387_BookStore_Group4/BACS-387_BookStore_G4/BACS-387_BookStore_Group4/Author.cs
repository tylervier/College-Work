﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class Author
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
