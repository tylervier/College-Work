﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.IO;

namespace BACS_387_BookStore_Group4
{
    public partial class AddBookAllDetailsWindow : Window
    {
        public AddBookAllDetailsWindow()
        {
            InitializeComponent();
        }
        public void btnAdd_Click(object sender, EventArgs e)
        {

            //Write
            Book writedata = new Book();
            writedata.title = txtTitle.Text;
            writedata.author = txtAuthor.Text;
            writedata.isbn = txtISBN.Text;
            Functions function = new Functions();
            function.writeFile(writedata);

            //Read
            Book readdata = new Book();
            string[] printArray = function.readFile(readdata);
            lstBook.Items.Clear();
            for (int i = 0; i < 50; i++)
            {
                string printString = "";
                printString = (printArray[i]);
                lstBook.Items.Add(printString);
            }
        }
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtAuthor.Clear();
            txtTitle.Clear();
            txtISBN.Clear();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Book editBook = new Book();
            BookFunctions edit = new BookFunctions();
            editBook.title = txtTitle.Text;
            editBook.author = txtAuthor.Text;
            editBook.isbn = txtISBN.Text;

            edit.changeBook(editBook);
        }
    }
}



