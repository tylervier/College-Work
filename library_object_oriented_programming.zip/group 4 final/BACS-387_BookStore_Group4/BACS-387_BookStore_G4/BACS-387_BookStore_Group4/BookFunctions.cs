﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BACS_387_BookStore_Group4
{
    class BookFunctions
    {
        public void AddBook(Book book)
        {
            book = book.CheckDigit10(book);
            if(book.check == true)
            {
                Functions addFunction = new Functions();
                addFunction.writeFile(book);
            }
        }
        public Book searchBook(Book book)
        {
            Functions search = new Functions();
            string[,] searchString = search.allBooks();

            for (int i = 0; i<100; i++)
            {
                if (book.isbn == searchString[i,2])
                {
                    book.check = true;
                    book.title = searchString[i, 0];
                    book.author = searchString[i, 1];
                }
            }
            return book;
        }
        public void removeBook(Book book)
        {
            Functions remove = new Functions();
            string[,] removeString = remove.allBooks();
            book.check = false;
            int index = 0;
            while (book.check == false && index < 100)
            {
                if (book.isbn == removeString[index, 2])
                {
                    book.check = true;
                }
                else
                {
                    index += 1;
                }
            }
            for (int i = index; i < 99; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    removeString[i, j] = removeString[i + 1, j];
                }
            }
            remove.reWriteBooks(removeString);
        }
        public void changeBook(Book changeBook)
        {
            Functions change = new Functions();
            string[,] changeString = change.allBooks();
            changeBook.check = false;
            int x = 0;
            while(changeBook.check == false && x < 100)
            {
                if (changeBook.isbn == changeString[x,2])
                {
                    changeString[x, 0] = changeBook.title;
                    changeString[x, 1] = changeBook.author;
                    changeBook.check = true;
                }
                x += 1;
            }
            if(changeBook.check == true)
            {
                change.reWriteBooks(changeString);
            }
        }

    }        
}

