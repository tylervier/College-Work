﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BACS_387_BookStore_Group4
{
    /// <summary>
    /// Interaction logic for AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void searchSaved_Click(object sender, RoutedEventArgs e)
        {
            var srchForm = new SearchWindow();
            this.Hide();
            srchForm.ShowDialog();
            this.Show();
        }

        private void logOut_Click(object sender, RoutedEventArgs e)
        {
            var loginForm = new MainWindow();
            this.Close();
            loginForm.Show();
        }

        private void isbnAdd_Click(object sender, RoutedEventArgs e)
        {
            var isbnAddForm = new ISBNAddBookWindow();
            this.Hide();
            isbnAddForm.ShowDialog();
            this.Show();
        }

        private void addBook_Click(object sender, RoutedEventArgs e)
        {
            var manualAddForm = new AddBookAllDetailsWindow();
            this.Hide();
            manualAddForm.ShowDialog();
            this.Show();
        }

        private void editBook_Click(object sender, RoutedEventArgs e)
        {
            var srchForm = new SearchWindow();
            this.Hide();
            srchForm.ShowDialog();
            this.Show();
        }

        private void removeBook_Click(object sender, RoutedEventArgs e)
        {
            var srchForm = new SearchWindow();
            this.Hide();
            srchForm.ShowDialog();
            this.Show();
        }
    }
}
