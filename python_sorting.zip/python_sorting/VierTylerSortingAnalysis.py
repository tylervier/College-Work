###########################################################################
#  bubbleSort                                                             #
#                                                                         #
#  Inserts an array and sorts it using the bubble sort sorting            #
#  Method                                                                 #
#                                                                         #
###########################################################################

import random

def bubbleSort(array, swaps, comps, loop):
    comps = comps + 1
    n = len(array)
    for j in range(n-1):
        comps = comps + 1
        if array[j] > array[j+1]:
            array[j], array[j+1] = array[j+1], array[j]
    return comps

###########################################################################
#  bubbleAnalysis                                                         #
#                                                                         #
#  Uses bubble sort to analyze the number of probes required              #
#  for the pre determined array size                                      #
#                                                                         #
###########################################################################

def bubbleAnalysis(arraylength):
    sum = 0
    for count in range(100):
        array = random.sample(range(1, arraylength + 1), arraylength)
        result = bubbleSort(array, 1, 1, 1)
        sum = sum + result
    print('%10d %19.2f'%(arraylength, sum/100))
     
###########################################################################
#  insertionSort                                                          #
#                                                                         #
#  Inserts an array and sorts it using the insertion sort sorting         #
#  Method                                                                 #
#                                                                         #
###########################################################################

def insertionSort(array, swaps, comps, loop):
    comps = comps + 1
    n = len(array)
    for i in range (1, n):
       val = array[i]
       pos = i
       comps = comps + 1
       while (pos>0) and (array[pos-1]>val):
           array[pos] = array[pos-1]
           pos = pos - 1
           comps = comps + 1
           array[pos] = val
    return comps

###########################################################################
#  insertionAnalysis                                                      #
#                                                                         #
#  Uses insertion sort to analyze the number of probes required           #
#  for the pre determined array size                                      #
#                                                                         #
###########################################################################

def insertionAnalysis(arraylength):
    sum = 0
    for count in range(100):
        array = random.sample(range(1, arraylength + 1), arraylength)
        result = insertionSort (array, 1, 1, 1)
        sum = sum + result
    print('%10d %19.2f'%(arraylength, sum/100))

###########################################################################
#  selectionSort                                                          #
#                                                                         #
#  Inserts an array and sorts it using the selection sort sorting         #
#  Method                                                                 #
#                                                                         #
###########################################################################

def selectionSort(array, swaps, comps, loop):
    comps = 0
    n = len(array)
    maxKey.count = 0
    for i in range(n-1, 0, -1):
        max = maxKey(0, i, array)
        temp = array[max]
        array[max] = array[i]
        array[i] = temp
    return maxKey.count

###########################################################################
#  selectionAnalysis                                                      #
#                                                                         #
#  Uses selection sort to analyze the number of probes required           #
#  for the pre determined array size                                      #
#                                                                         #
###########################################################################

def selectionAnalysis(arraylength):
    sum = 0
    for count in range(100):
        array = random.sample(range(1, arraylength + 1), arraylength)
        result = selectionSort (array, 1, 1, 1)
        sum = sum + result
    print('%10d %19.2f'%(arraylength, sum/100))

###########################################################################
#  maxKey                                                                 #
#                                                                         #
#  maxKey is used for the selection sort to determine the arrays size     #
#  after going through the selection sort                                 #
#                                                                         #
###########################################################################

def maxKey(low, high, array):
    largest = low
    for j in range (low+1, high+1):
        maxKey.count += 1
        if array[largest] < array[j]:
            largest = j
    return largest

###########################################################################
#  quickSort                                                              #
#                                                                         #
#  Inserts an array and sorts it using the quick sort sorting             #
#  Method                                                                 #
#                                                                         #
###########################################################################

level = 1
comps = 0
swaps = 0

def quickSort(array, lo, hi):
    sum = 0
    if lo < hi:
        split = partition(array, lo, hi)
        comps = split[1]
        sum += comps
        quickSort(array, lo, split[0]-1)        
        quickSort(array, split[0]+1, hi)
    return(array, sum)

###########################################################################
#  quickAnalysis                                                          #
#                                                                         #
#  Uses quick sort to analyze the number of probes required               #
#  for the pre determined array size                                      #
#                                                                         #
###########################################################################

def quickAnalysis(arraylength):
    sum = 0
    for count in range(100):
        array = random.sample(range(1, arraylength + 1), arraylength)
        result = quickSort (array, 0, len(array)-1)
        sum = sum + result[1]
        sum += comps
    print('%10d %19.2f'%(arraylength, sum/10000))

###########################################################################
#  partition                                                              #
#                                                                         #
#  partition is used for the quick sort to determine the arrays size      #
#  after going through the quick sort                                     #
#                                                                         #
###########################################################################

def partition(array, lo, hi):
    global comps, swaps, level 
    pivot = array[hi]
    i = lo
    for j in range (lo, hi):
        comps += 1
        if array[j] <= pivot:
            array[i], array[j] = array[j], array[i]
            swaps += 1
            i = i + 1
            
    level = level + 1
    array[hi], array[i] = array[i], array[hi]
    return (i, comps)
