from VierTylerSorting import bubbleSort, insertionSort, selectionSort, maxKey


print ("Tyler Vier")
print ("Sorting Algorithms\n")

print ("##################################################################\n")

print ("Bubble Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

#bubble sort
bubbleSort (array, 1, 1, 1)

print ("\n##################################################################\n")

print ("Insertion Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

#insertion sort
insertionSort (array, 1, 1, 1)

print ("\n##################################################################\n")

print ("Selection Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

selectionSort (array, 1, 1, 1)
