from VierTylerSorting2 import bubbleSort, insertionSort, selectionSort, maxKey, partition, quickSort, printAnalysis


print ("Tyler Vier")
print ("Sorting Algorithms\n")

print ("##################################################################\n")

print ("Bubble Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

#bubble sort
bubbleSort (array, 1, 1, 1)

print ("\n##################################################################\n")

print ("Insertion Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

#insertion sort
insertionSort (array, 1, 1, 1)

print ("\n##################################################################\n")

print ("Selection Sort")

#base array
array = [3, 1, 4, 1, 5, 9, 2, 6]

#selection sort
selectionSort (array, 1, 1, 1)

print ("\n##################################################################\n")

print ("Quick Sort")

#base array
array = [69, 81, 22, 48, 13, 38, 93, 14, 45, 58, 79, 72]

#quick sort
quickSort (array, 0, len(array)-1)
printAnalysis()
print (array)

