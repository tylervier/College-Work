###########################################################################
#  bubbleSort                                                             #
#                                                                         #
#  Inserts an array and sorts it using the bubble sort sorting            #
#  Method                                                                 #
#                                                                         #
###########################################################################

def bubbleSort(array, swaps, comp, loop):
    i = 0
    j = 1
    n = len(array)
    for j in range(n-1):
        print ("\nLoop #" + str(loop), "        Array = ", array)
        loop = loop + 1
        for j in range(n-1):
            print ("     Comparisons #" + str(comp), end="")
            if comp < 10:
                print("       ", end="")
            elif comp >= 10:
                print("      ", end="")
            for i in range(j):
                print("   ", end="")
            print(array[j], " " + str(array[j+1]))
            comp = comp + 1
            if array[j] > array [j + 1]:
                print("     Swap #", swaps, end="")
                print("             ", end="")
                for i in range(j):
                    print("   ", end="")
                print(array[j+1], " " + str(array[j]))
                swaps = swaps + 1
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
                j = j+1
                    
    print("\nAnalysis:")
    comp = comp - 1
    print("   Comparisons:   ", comp)
    swaps = swaps - 1
    print("   Swaps:          ", swaps)
    work = (comp - (swaps*5))
    print("   Work:           ", work)
     
###########################################################################
#  insertionSort                                                          #
#                                                                         #
#  Inserts an array and sorts it using the insertion sort sorting         #
#  Method                                                                 #
#                                                                         #
###########################################################################

def insertionSort(array, swaps, comp, loop):
    i = 1
    n = len(array)
    for i in range (1, n):
        j = i
        print ("Loop #", loop, ":   Array = ", array)
        loop = loop + 1
        if j > 0 and array[j-1] > array[i]:
            while j > 0 and array[j-1] > array[j]:
                print("   Comparison #" + str(comp), end="")
                if comp < 10:
                    print ("    ", end="")
                elif comp >= 10:
                    print ("   ", end="")
                for i in range(j):
                    print("   ", end="")
                print(array[j-1], " " + str(array[j]))
                comp = comp + 1
                print("     Swap #", swaps, end="")
                print("       ", end="")
                for i in range(j):
                    print("   ", end="")
                print(array[j], " " + str(array[j-1]))
                swaps = swaps + 1
                temp = array[j]
                array[j] = array[j-1]
                array[j-1] = temp
                j -= 1
        elif j > 0 and array[j-1] <= array[j]:
            print("     Comparison #" + str(comp), end="")
            if comp < 10:
                print("    ", end="")
            elif comp >= 10:
                print("   ", end="")
            for i in range(j):
                print("  ", end="")
            print(array[j-1], " " + str(array[j]))
            comp = comp + 1
            j -= 1
    print("\nAnalysis:")
    comp = comp - 1
    print("   Comparisons:   ", comp)
    swaps = swaps - 1
    print("   Swaps:          ", swaps)
    work = (comp + (swaps*5))
    print("   Work:          ", work)

###########################################################################
#  selectionSort                                                          #
#                                                                         #
#  Inserts an array and sorts it using the selection sort sorting         #
#  Method                                                                 #
#                                                                         #
###########################################################################

def selectionSort(array, swaps, comp, loop):
    n = len(array)
    maxKey.count = 0
    for i in range(n-1, 0, -1):
        print ("Loop #" + str(loop), ":     Array: ", array)
        loop = loop + 1  
        max = maxKey(0, i, array)
        print("   Swap #" + str(swaps), end="")
        print("        ", end="")
        if i-max <=2 and i-max > 1:
            print(str(array[i]).rjust(i*3) + str(array[max]).rjust((i-max)*3))
            swaps = swaps + 1
        elif i-max > 2:
            print(str(array[i]).rjust(i*3-3) + str(array[max]).rjust((i-max)*3))
            swaps = swaps + 1
        elif i-max <= 1:
            print(str(array[i]).rjust(i*3+3) + str(array[max]).rjust(3))
            swaps = swaps + 1
        temp = array[max]
        array[max] = array[i]
        array[i] = temp
    print("\nAnalysis:")
    comp = comp - 1
    print("   Comparisons:   ", maxKey.count)
    swaps = swaps - 1
    print("   Swaps:          ", swaps)
    work = (maxKey.count + (swaps*5))
    print("   Work:          ", work)

###########################################################################
#  maxKey                                                                 #
#                                                                         #
#  maxKey is used for the selection sort to determine the arrays size     #
#  after going through the selection sort                                 #
#                                                                         #
###########################################################################

def maxKey(low, high, array):
    largest = low
    for j in range (low+1, high+1):
        maxKey.count += 1
        if array[largest] < array[j]:
            largest = j
        if maxKey.count < 10:
            print("   Comparison #" + str(maxKey.count), "      ", str(array[j]).rjust(j*3),
                  str("max=").rjust(28-j*3) + str(array[largest]), "   array[" + str(largest) + "]")
        elif maxKey.count >=10:
            print("   Comparison #" + str(maxKey.count), "     ", str(array[j]).rjust(j*3),
                  str("max=").rjust(28-j*3) + str(array[largest]), "   array[" + str(largest) + "]")
    return largest
