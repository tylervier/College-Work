from VierTylerSortingAnalysis import bubbleAnalysis, insertionAnalysis, selectionAnalysis, quickAnalysis


print ("Tyler Vier")
print ("Sorting Analysis\n")

print ("##################################################################\n")

print ("Bubble Sort Analysis\n")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#bubbleAnalysis
bubbleAnalysis (10)
bubbleAnalysis (50)
bubbleAnalysis (100)
bubbleAnalysis (500)
bubbleAnalysis (1000)

print ("\n##################################################################\n")

print ("Insertion Sort Analysis")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#insertionAnalysis
insertionAnalysis (10)
insertionAnalysis (50)
insertionAnalysis (100)
insertionAnalysis (500)
insertionAnalysis (1000)

print ("\n##################################################################\n")

print ("Selection Sort Analysis")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#selectionAnalysis
selectionAnalysis (10)
selectionAnalysis (50)
selectionAnalysis (100)
selectionAnalysis (500)
selectionAnalysis (1000)

print ("\n##################################################################\n")

print ("Quick Sort Analysis")

print ("ARRAY SIZE   AVERAGE PROBES REQUIRED")

#quickAnalysis
quickAnalysis (10)
quickAnalysis (50)
quickAnalysis (100)
quickAnalysis (500)
quickAnalysis (1000)
